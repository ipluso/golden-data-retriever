-- -------------------------------------------------------------
-- TablePlus 6.7.8(650)
--
-- https://tableplus.com/
--
-- Database: db
-- Generation Time: 2025-12-18 20:49:47.1880
-- -------------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


DROP TABLE IF EXISTS `drc_parameters`;
CREATE TABLE `drc_parameters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `param_key` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `target_column` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `drc_parameters_param_key_unique` (`param_key`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `drc_parameters` (`id`, `param_key`, `category`, `description`, `label`, `target_column`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'CondOA_1', 'Auflagen', 'ohne Auflagen', 'HD', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(2, 'CondOA_2', 'Auflagen', 'ohne Auflagen', 'ED', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(3, 'CondOA_3', 'Auflagen', 'ohne Auflagen', 'HC', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(4, 'CondOA_4', 'Auflagen', 'ohne Auflagen', 'RD', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(5, 'CondOA_41', 'Auflagen', 'ohne Auflagen', 'Gonio', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(6, 'CondOA_5', 'Auflagen', 'ohne Auflagen', 'WT', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(7, 'CondOA_6', 'Auflagen', 'ohne Auflagen', 'FW', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(8, 'CondOA_7', 'Auflagen', 'ohne Auflagen', 'Gebiss', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(9, 'CondOA_8', 'Auflagen', 'ohne Auflagen', 'PRA', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(10, 'CondOA_9', 'Auflagen', 'ohne Auflagen', 'Leistung', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(11, 'CondOA_10', 'Auflagen', 'ohne Auflagen', 'Gentest', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(12, 'CondOA_11', 'Auflagen', 'ohne Auflagen', 'Sonst', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(13, 'CondMA_1', 'Auflagen', 'mit Auflagen', 'HD', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(14, 'CondMA_2', 'Auflagen', 'mit Auflagen', 'ED', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(15, 'CondMA_3', 'Auflagen', 'mit Auflagen', 'HC', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(16, 'CondMA_4', 'Auflagen', 'mit Auflagen', 'RD', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(17, 'CondMA_41', 'Auflagen', 'mit Auflagen', 'Gonio', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(18, 'CondMA_5', 'Auflagen', 'mit Auflagen', 'WT', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(19, 'CondMA_6', 'Auflagen', 'mit Auflagen', 'FW', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(20, 'CondMA_7', 'Auflagen', 'mit Auflagen', 'Gebiss', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(21, 'CondMA_8', 'Auflagen', 'mit Auflagen', 'PRA', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(22, 'CondMA_9', 'Auflagen', 'mit Auflagen', 'Leistung', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(23, 'CondMA_10', 'Auflagen', 'mit Auflagen', 'Gentest', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(24, 'CondMA_11', 'Auflagen', 'mit Auflagen', 'Sonst', 'orthopedic_details', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(25, 'CondGT_01', 'Gentests-1', 'prcd PRA', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(26, 'CondGT_02', 'Gentests-1', 'prcd PRA', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(27, 'CondGT_03', 'Gentests-1', 'prcd PRA', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(28, 'CondGT_04', 'Gentests-1', 'prcd PRA', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(29, 'CondGT_05', 'Gentests-1', 'CNM', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(30, 'CondGT_06', 'Gentests-1', 'CNM', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(31, 'CondGT_07', 'Gentests-1', 'CNM', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(32, 'CondGT_08', 'Gentests-1', 'CNM', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(33, 'CondGT_09', 'Gentests-1', 'EIC', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(34, 'CondGT_10', 'Gentests-1', 'EIC', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(35, 'CondGT_11', 'Gentests-1', 'EIC', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(36, 'CondGT_12', 'Gentests-1', 'EIC', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(37, 'CondGT_13', 'Gentests-1', 'NARC', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(38, 'CondGT_14', 'Gentests-1', 'NARC', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(39, 'CondGT_15', 'Gentests-1', 'NARC', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(40, 'CondGT_16', 'Gentests-1', 'NARC', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(41, 'CondGT_17', 'Gentests-1', 'RD OSD', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(42, 'CondGT_18', 'Gentests-1', 'RD OSD', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(43, 'CondGT_19', 'Gentests-1', 'RD OSD', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(44, 'CondGT_20', 'Gentests-1', 'RD OSD', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(45, 'CondGT_21', 'Gentests-1', 'DM', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(46, 'CondGT_22', 'Gentests-1', 'DM', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(47, 'CondGT_23', 'Gentests-1', 'DM', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(48, 'CondGT_24', 'Gentests-1', 'DM', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(49, 'CondGT_25', 'Gentests-1', 'CEA CH', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(50, 'CondGT_26', 'Gentests-1', 'CEA CH', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(51, 'CondGT_27', 'Gentests-1', 'CEA CH', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(52, 'CondGT_28', 'Gentests-1', 'CEA CH', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(53, 'CondGT_30', 'Gentests-1', 'SD2', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(54, 'CondGT_31', 'Gentests-1', 'SD2', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(55, 'CondGT_32', 'Gentests-1', 'SD2', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(56, 'CondGT_33', 'Gentests-1', 'SD2', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(57, 'CondGT_34', 'Gentests-2', 'GR-PRA1', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(58, 'CondGT_35', 'Gentests-2', 'GR-PRA1', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(59, 'CondGT_36', 'Gentests-2', 'GR-PRA1', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(60, 'CondGT_37', 'Gentests-2', 'GR-PRA1', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(61, 'CondGT_38', 'Gentests-2', 'GR-PRA2', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(62, 'CondGT_39', 'Gentests-2', 'GR-PRA2', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(63, 'CondGT_40', 'Gentests-2', 'GR-PRA2', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(64, 'CondGT_41', 'Gentests-2', 'GR-PRA2', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(65, 'CondGT_42', 'Gentests-1', 'HNPK', 'frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(66, 'CondGT_43', 'Gentests-1', 'HNPK', 'Träger', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(67, 'CondGT_44', 'Gentests-1', 'HNPK', 'betroffen', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(68, 'CondGT_45', 'Gentests-1', 'HNPK', 'über Erbgang frei', 'genetic_tests', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(69, 'CondJG_01', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'JAS', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(70, 'CondJG_02', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'BLP/R', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(71, 'CondJG_03', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'RGP', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(72, 'CondJG_04', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'PnS', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(73, 'CondJG_05', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'HP/R', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(74, 'CondJG_06', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'JEP', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(75, 'CondJG_07', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'VJP', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(76, 'CondJG_08', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'VSWP', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(77, 'CondJG_09', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'VGP', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(78, 'CondJG_10', 'Prüfungen/Titel', 'jagdl. Prüfungen', 'BTR', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(79, 'CondSO_01', 'Prüfungen/Titel', 'nicht jagdl.', 'Wesenstest', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(80, 'CondSO_02', 'Prüfungen/Titel', 'nicht jagdl.', 'BHP', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(81, 'CondSO_03', 'Prüfungen/Titel', 'nicht jagdl.', 'Dummy', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(82, 'CondAU_01', 'Prüfungen/Titel', 'Dt. Ch. Titel', 'Jugend Ch.', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(83, 'CondAU_02', 'Prüfungen/Titel', 'Dt. Ch. Titel', 'Deu. Ch.', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(84, 'CondAU_03', 'Prüfungen/Titel', 'Dt. Ch. Titel', 'Deu.Arb.Ch.', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(85, 'CondAU_04', 'Prüfungen/Titel', 'Dt. Ch. Titel', 'VDH Ch.', 'work_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(86, 'CondAG_01', 'Augen', 'Gonio: kurze Trabekel', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(87, 'CondAG_02', 'Augen', 'Gonio: kurze Trabekel', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(88, 'CondAG_03', 'Augen', 'Gonio: kurze Trabekel', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(89, 'CondAG_04', 'Augen', 'Gonio: Gewebebruecken', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(90, 'CondAG_05', 'Augen', 'Gonio: Gewebebruecken', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(91, 'CondAG_06', 'Augen', 'Gonio: Gewebebruecken', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(92, 'CondAG_07', 'Augen', 'Gonio: total Dysplasie', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(93, 'CondAG_08', 'Augen', 'Gonio: total Dysplasie', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(94, 'CondAG_09', 'Augen', 'Gonio: total Dysplasie', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(95, 'CondRD_01', 'Augen', 'RD: multifokal', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(96, 'CondRD_02', 'Augen', 'RD: multifokal', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(97, 'CondRD_03', 'Augen', 'RD: multifokal', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(98, 'CondRD_04', 'Augen', 'RD: geografisch', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(99, 'CondRD_05', 'Augen', 'RD: geografisch', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(100, 'CondRD_06', 'Augen', 'RD: geografisch', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(101, 'CondRD_07', 'Augen', 'RD: total', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(102, 'CondRD_08', 'Augen', 'RD: total', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(103, 'CondRD_09', 'Augen', 'RD: total', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(104, 'CondPRA_01', 'Augen', 'PRA', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(105, 'CondPRA_02', 'Augen', 'PRA', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(106, 'CondPRA_03', 'Augen', 'PRA', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(107, 'CondHC_01', 'Augen', 'HC: cortikales', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(108, 'CondHC_02', 'Augen', 'HC: cortikales', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(109, 'CondHC_03', 'Augen', 'HC: cortikales', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(110, 'CondHC_04', 'Augen', 'HC: post pol', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(111, 'CondHC_05', 'Augen', 'HC: post pol', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(112, 'CondHC_06', 'Augen', 'HC: post pol', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(113, 'CondHC_07', 'Augen', 'HC: sutura ant', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(114, 'CondHC_08', 'Augen', 'HC: sutura ant', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(115, 'CondHC_09', 'Augen', 'HC: sutura ant', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(116, 'CondHC_10', 'Augen', 'HC: punctata', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(117, 'CondHC_11', 'Augen', 'HC: punctata', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(118, 'CondHC_12', 'Augen', 'HC: punctata', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(119, 'CondHC_13', 'Augen', 'HC: nuklearis', 'frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(120, 'CondHC_14', 'Augen', 'HC: nuklearis', 'nicht frei', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57'),
(121, 'CondHC_15', 'Augen', 'HC: nuklearis', 'zweifelhaft', 'eye_exams', NULL, '2025-12-15 13:16:57', '2025-12-15 13:16:57');



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;